/*  C Program to Reverse each word in a sentence  */

#include <stdio.h>

int main()
{

    char str[100], text[100];
    int i = 0, j = 0;
    printf("\nEnter any Sentence :: ");
    gets(str);

    // Character reversing starts
    while (str[i] != '\0')
        i++;
    while (i > 0)
    {

        text[j] = str[i-1];
        i--;
        j++;
    }
    text[j] = '\0';
    j=0;
    while (text[j] != '\0')
    {
        printf("%c", text[j]);
        j++;
    }

    return 0;
}
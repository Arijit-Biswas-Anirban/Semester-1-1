
#include <stdio.h>
#include <stdlib.h>

int main() {
    int *arr, n, i, j, k;

    scanf("%d", &n);
    arr = (int *)malloc(n * sizeof(int));


    int *ptr = arr;

    for (i = 0; i < n; i++) {
        scanf("%d", ptr);
        ptr++;
    }


    int *start = arr;
    int *end = arr + n - 1;
    while (start < end) {
        int temp = *start;
        *start = *end;
        *end = temp;
        start++;
        end--;
    }


    ptr = arr;
    for (i = 0; i < n; i++) {
        printf("%d ", *ptr);
        ptr++;
    }

    free(arr);

    return 0;
}

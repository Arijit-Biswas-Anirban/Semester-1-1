
#include<stdio.h>
int main()
{
    int num,sum=0,temp_num;
    scanf("%d", &num);
    temp_num = num;
    while(num!=0)
    {
        int digit = num % 10;
        sum = sum*10 + digit;
        num /= 10;
    }

    if(sum == temp_num)
        printf("Palindrome");
    else
        printf("Not Palindrome");

    return 0;

}

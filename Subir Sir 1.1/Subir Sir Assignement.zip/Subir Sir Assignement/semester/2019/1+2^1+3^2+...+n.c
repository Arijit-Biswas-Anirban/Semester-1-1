#include <stdio.h>
int main()
{
    int n, i, j, sum = 0,temp;
    ;
    scanf("%d", &n);

    for (i = 1; i <= n; i++)
    {
        temp = 1;
        for(j=1; j<i; j++)
            temp *=i;
        sum += temp;
    }
    printf("%d", sum);
    return 0;
}

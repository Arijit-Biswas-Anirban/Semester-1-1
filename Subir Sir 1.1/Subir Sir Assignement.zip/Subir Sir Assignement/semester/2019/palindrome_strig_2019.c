#include <stdio.h>

int main()
{
    int i, j, count = 0, flag = 1;
    char arr[30];

    gets(arr);
    for(i = 0; i < 30; i++)
    {
        if (arr[i] == '\0')
            break;
        count++;
    }

    for(i = 0, j = count - 1; i < j; i++, j--)
    {
        if(arr[i] != arr[j])
        {
            flag = 0;
            break;
        }
    }

    if(flag)
        printf("Y");
    else
        printf("N");

    return 0;
}


#include<stdio.h>
#include<stdlib.h>
int main()
{
    int n,m,i,j,k;
    char *s1,c;
    printf("first string n: ");
    scanf("%d%c", &n,&c);

    s1 = (char *)malloc((n+m+1) * sizeof(char));
    gets(s1);

    char *s2,c2;
    printf("second string m: ");
    scanf("%d%c", &m,&c2);

    s2 = (char *)malloc((m) * sizeof(char));
    gets(s2);

    for(i=m+1,j=0; j<n; i++,j++)
    {
        s1[i] = s1[j];
    }
    s1[i] = '\0';
    for(j=0; s2[j]!='\0'; j++)
    {
        s1[j] = s2[j];
    }
    s1[m] = ' ';
    puts(s1);
    free(s1);
    free(s2);
    return 0;
}

#include<stdio.h>
int main(){
    int year,isLeap=0;
    scanf("%d", &year);

    if((year%4 == 0) && (year%100 != 0) || year%400 == 0)
        isLeap=1;

    if(isLeap)
        printf("Yes\n");
    else
        printf("No\n");

    return 0;
}

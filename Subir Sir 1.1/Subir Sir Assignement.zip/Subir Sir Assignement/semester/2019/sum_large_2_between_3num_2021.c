#include<stdio.h>
int main()
{
    int a,b,c,sum=0;
    scanf("%d%d%d", &a,&b,&c);
    int min = a;
    if(min > b)
        min = b;
    else if(min > c)
        min = c;
    if(min == a)
        a=0;
    else if(min == b)
        b=0;
    else
        c=0;

    sum = a+b+c;

    printf("%d", sum);
    return ;
}

#include<stdio.h>
int main()
{
    struct student{
        char name[20];
        int roll;
        float CSE;
        float PHY;
        float HUM;
    };

    struct student students[3];
    int i,j;
    for(i=0;i<3;i++)
    {
        printf("Enter student %d attributes:\n", i+1);
        printf("Name: ");
        scanf("%s", &students[i].name);
        printf("Roll: ");
        scanf("%d", &students[i].roll);
        printf("CSE 1101 Mark: ");
        scanf("%f", &students[i].CSE);
        printf("PHY 1101 Mark: ");
        scanf("%f", &students[i].PHY);
        printf("HUM 1101 Mark: ");
        scanf("%f", &students[i].HUM);
    }
    for(j=0;j<3;j++)
    {
        float avg = (students[j].CSE + students[j].PHY+students[j].HUM) / 3.0;
        printf("Student %d:\n", j+1);
        printf("Name: %s\n", students[j].name);
        printf("Roll: %d\n", students[j].roll);
        printf("Average Marks: %.3f\n", avg);
    }

    return 0;
}

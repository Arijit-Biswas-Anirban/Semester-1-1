#include<stdio.h>
int rev(int a, int b){
    if(a==0)
        return b;
    else
        return rev(a/10,(b*10)+(a%10));

}
int main()
{
    int num;
    scanf("%d", &num);
    int result = rev(num,0);

    printf("%d\n", result);
    return 0;
}

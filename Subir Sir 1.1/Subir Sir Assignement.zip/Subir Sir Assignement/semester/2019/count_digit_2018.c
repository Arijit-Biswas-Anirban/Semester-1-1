#include <stdio.h>
int main()
{
    int num, count=0, digit;
    scanf("%d", &num);

    if(num>=0 && num<=50000)
    {
        while(num!=0)
        {
            digit = num % 10;
            count++;
            num /= 10;
        }
        printf("%d\n", count);
    }


    return 0;
}

/*
     1
    232
   34543
  4567654
 567898765
67890123456
*/
#include <stdio.h>

int main()
{
    int row, sp, i, j, k;

    scanf("%d", &row);

    for (i = 1; i <= row; i++)
    {
        for (sp = 1; sp <= (row - i); sp++)
            printf(" ");
        for (j = i; j <= (2 * i - 1); j++)
            printf("%d", j % 10);

        if(2*i - 2 <10)
        {
            for (k = (2 * i - 2); k >= i; k--)
            printf("%d", k % 10);
        }
        else if(2*i - 2 >=10)
        {
            for(k=(2*i); k<=(i+10); k++)
                printf("%d", k%10);
        }



        printf("\n");
    }

    return 0;
}

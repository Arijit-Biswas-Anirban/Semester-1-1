#include<stdio.h>
int main()
{
    int row,sp,i,j,k;
    scanf("%d", &row);

    for(i=1; i<=row; i++)
    {
        for(sp=1; sp<=(row-i); sp++)
            printf(" ");
        for(j=2*i - 1; j>0; j--)
        {
            printf("A");
        }
        printf("\n");
    }


    return 0;

}

#include<stdio.h>
int main()
{
    int x=10,y=20;
    x++;
    x = x<y ? x++:x+y;

    printf("%d %d", x, y);

    return 0;

}

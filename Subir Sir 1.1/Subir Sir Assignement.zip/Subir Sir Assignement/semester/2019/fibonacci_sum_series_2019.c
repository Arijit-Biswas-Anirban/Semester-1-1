#include<stdio.h>
int main(){
    int n,a=0,b=1,c=1,i,j,sum=0;
    scanf("%d", &n);

    for(i=1;i<=n;i++)
    {
        sum += c;
        c = a+b;
        a = b;
        b = c;
    }
    printf("Sum : %d\nSeries : ", sum);
    a=1,b=1,c=0;
    for(i=1;i<=n;i++)
    {
        if(i==1||i==2)
            printf("%d+", 1);
        else
        {
            c = a+b;
            printf("%d", c);
            if(i!=n)
                printf("+");
            a = b;
            b = c;
        }
    }
    printf("+...+n");

    return 0;
}

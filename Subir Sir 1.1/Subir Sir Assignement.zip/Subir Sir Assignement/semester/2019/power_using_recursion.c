#include<stdio.h>
int pow(int a, int b){
    if(b==0)
        return 1;
    else
        return a*pow(a,b-1);

}
int main()
{
    int base,power;
    scanf("%d %d", &base, &power);
    int result = pow(base,power);
    printf("%d\n", result);

    return 0;
}

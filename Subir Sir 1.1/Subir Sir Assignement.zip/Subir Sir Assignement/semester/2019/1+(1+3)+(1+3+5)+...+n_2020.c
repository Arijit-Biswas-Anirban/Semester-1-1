#include<stdio.h>
int main()
{
    int n,i,j,k,sum=0;
    scanf("%d", &n);

    for(i=1;i<=n;i++)
    {
        if(i==1)
        {
            sum += i;
        }
        else
        {
            for(j=0,k=1;k<=i;j++,k++)
            {
                int tmp = 2*j+1;
                sum += tmp;
            }
        }

    }
    printf("Sum : %d\n", sum);
    for(i=1;i<=n;i++)
    {
        if(i==1)
        {
            printf("%d", i);
            sum += i;
        }
        else
        {
            printf("+(");
            for(j=0,k=1;k<=i;j++,k++)
            {
                int temp = 2*j + 1;
                sum += temp;
                printf("%d", temp);
                if(k!=i)
                    printf("+");
            }
            printf(")");
        }

    }
    printf("+...+n");




    return 0;
}

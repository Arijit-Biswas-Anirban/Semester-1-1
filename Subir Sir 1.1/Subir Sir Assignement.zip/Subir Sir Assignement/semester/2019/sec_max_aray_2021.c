#include<stdio.h>
#include<stdlib.h>
int main(){
    int *arr, n, i, j;
    scanf("%d", &n);

    arr = (int *)malloc(n*sizeof(int));

    for(i=0;i<n;i++)
        scanf("%d", &arr[i]);
    int max = arr[0];
    int sec_max = arr[1];
    for(j=0;j<n;j++)
    {
        if(max<arr[j])
        {
            sec_max = max;
            max = arr[j];
        }
        else if(sec_max<arr[j] && arr[j]!=max)
        {
            sec_max = arr[j];
        }
    }
    printf("%d", sec_max);

    return 0;
}

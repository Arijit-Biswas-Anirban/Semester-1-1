#include<stdio.h>
int main(){
    int a,b;
    scanf("%d %d", &a, &b);

    printf("Before swapping: ");
    printf("a=%d and b=%d\n", a, b);

    printf("After swapping: ");

    a = a - b;
    b = b + a;
    a = b - a;

    printf("a=%d and b=%d\n", a, b);


    return 0;
}

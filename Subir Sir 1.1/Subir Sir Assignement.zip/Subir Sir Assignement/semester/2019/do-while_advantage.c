#include<stdio.h>
int main()
{
    char pass[20];
    char correct_pass[] = {"secret anu"};
    int flag,i;

    do
    {
        printf("Enter the password: ");
        gets(pass);
        flag=5;
        for(i=0; correct_pass[i]!='\0'; i++)
        {
            if(correct_pass[i] != pass[i])
            {
                flag = 1;
                printf("Incorrect password. Please try again.\n");
                break;
            }
        }

    }
    while(flag==1);

    if(flag==5)
        printf("Access granted!");

    return 0;
}

#include<stdio.h>
#include<stdlib.h>
int main()
{
    int *arr,n,i,j;
    scanf("%d", &n);

    arr = (int *)malloc(n * sizeof(int));

    for(i=0;i<n;i++)
    {
        scanf("%d", &arr[i]);
    }
    for(j=0;j<n;j++)
    {
        if(arr[j] > 50)
            arr[j] = -99;
    }
    for(i=0;i<n;i++)
        printf("%d ", arr[i]);

    return 0;
}

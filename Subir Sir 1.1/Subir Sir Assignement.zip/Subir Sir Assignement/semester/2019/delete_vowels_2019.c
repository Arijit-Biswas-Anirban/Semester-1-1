#include<stdio.h>
int main()
{
    char arr[100];
    int i,j;

    gets(arr);

    for(i=0, j=0; arr[i]!='\0'; i++)
    {
        if(arr[i]!= 'A' && arr[i] != 'a' && arr[i] != 'E' && arr[i] != 'e' && arr[i] != 'I' && arr[i]!= 'i' && arr[i] != 'O' && arr[i] != 'o'
                && arr[i] != 'U' && arr[i] != 'u')
        {
            arr[j] = arr[i];
            j++;
        }
    }
    arr[j] = '\0';
    puts(arr);


    return 0;
}

#include<stdio.h>
#include<stdlib.h>
int main()
{
    int n,m,i,j;
    char *s1,c;
    printf("first string n: ");
    scanf("%d%c", &n,&c);

    s1 = (char *)malloc((n+m+1) * sizeof(char));
    gets(s1);

    char *s2,c2;
    printf("second string m: ");
    scanf("%d%c", &m,&c2);

    s2 = (char *)malloc((m) * sizeof(char));
    gets(s2);

    s1[n] = ' ';

    for(i=n+1,j=0;s2[j]!='\0';i++,j++)
    {
        s1[i] = s2[j];
    }
    s1[i] = '\0';
    puts(s1);
    free(s1);
    free(s2);
    return 0;
}

#include<stdio.h>
int main()
{
    char arr[100];
    int len=0, i, j;

    gets(arr);
    for(i=0; i<100; i++)
    {
        if(arr[i]=='\0')
            break;
        len++;
    }
    for(i=0;i<len;i++)
    {
        if(arr[i]>='A' && arr[i]<='Z')
            arr[i] = 'A' + (arr[i] - 'A' + 32);
    }

    puts(arr);

    return 0;
}


#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, i, flag = 1;
    char *arr, ch;

    scanf("%d", &n);
    arr = (char *)malloc(n * sizeof(char));
    scanf(" ");

    char *ptr = arr;

    for (i = 0; i < n; i++) {
        scanf("%c", ptr);
        ptr++;
    }

    char *start = arr;
    char *end = arr + n - 1;
    while (start < end) {
        if(*start != *end)
        {
            flag = 0;
            break;
        }
        start++;
        end--;
    }

    if(flag)
        printf("Yes");
    else
        printf("No");

    free(arr);

    return 0;
}


#include <stdio.h>
int main()
{
    int n, i, j, sum = 0;
    ;
    scanf("%d", &n);

    for (i = 1; i <= n; i++)
    {
        sum = 0;
        if (i == 1)
            sum += i;
        else
        {
            for (j = i-1; j>0; j--)
            {

                sum += i * j;
            }
        }
    }
    printf("%d", sum);
    return 0;
}

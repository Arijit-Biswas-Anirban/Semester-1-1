#include <stdio.h>
int main()
{
    int n, i, sum = 0;
    scanf("%d", &n);

    for(i=0;i<n;i++)
    {
        int temp = i*2 + 1;
        sum += temp;
        if(i == (n-1))
            printf("%d", temp);
        else
            printf("%d + ", temp);
    }
    printf(" = %d\n", sum);

    return 0;
}

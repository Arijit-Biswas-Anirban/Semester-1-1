//print Hello World without using semicolon
#include <stdio.h>
int main()
{

    
    if (printf("Hello World\n"))
    {
        
    }
    

    return 0;
}